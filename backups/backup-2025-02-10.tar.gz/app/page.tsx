import { HomeFeed } from "@/components/home-feed";
import { getBrands } from "@/lib/brands";

export default async function Home() {
  const brands = await getBrands();
  const sheetName = process.env.GOOGLE_SHEETS_BRANDS_SHEET ?? "Brands";
  const publishedUrl = process.env.GOOGLE_SHEETS_PUBLISHED_URL ?? "";
  const sheetSourceLabel = publishedUrl
    ? publishedUrl.replace(/^https?:\/\//, "").slice(0, 60)
    : "not set";

  return (
    <div className="min-h-screen bg-[#fbfbfb] font-sans text-zinc-900">
      <main className="mx-auto flex w-full max-w-6xl flex-col gap-10 px-4 py-12 sm:px-8">
        <section className="hero">

        </section>
        <HomeFeed brands={brands} />
      </main>
    </div>
  );
}
